import java.util.*;
import java.util.Scanner;
public class Even_odd
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int count=0;
	    int count1=0;
	    
               int n=sc.nextInt();
               for(int i=1;i<=n;i++){
                   if(n%i==0){
                           if(i%2==0){
                                count++;
                           }
                           else{
                            count1++;
                           }
                   }
               }
               if(count==count1){
                   System.out.println(1);
               }
               else{
                   System.out.println(0);
               }
	}}
