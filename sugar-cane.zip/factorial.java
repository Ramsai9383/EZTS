import java.util.*;
import java.lang.*;
import java.io.*;

class Main
{
	public static void main (String[] args) throws java.lang.Exception
	{
        Scanner sc=new Scanner(System.in);
	   
	       int n=sc.nextInt();
	       System.out.println(fact(n));
	       
	}
	public static int fact(int n){
	    int res=1;
	       while(n>0){
	          res=n*res;
	          n--;
	       }
	       return res;
	}
    
}
// Another approach:
// recursion:
// if(n==1 || n==0){
//     return 1;
// }
// else{
//     return(n*fact(n-1));
// }