import java.util.*;
import java.util.Scanner;
public class Running
{
  public static void main (String[]args)
  {
	Scanner sc = new Scanner (System.in);
	int count = 0;
	int n = sc.nextInt ();
	int alice[] = new int[n];
	int bob[] = new int[n];

	for (int i = 0; i < n; i++)
	  {
		alice[i] = sc.nextInt ();
	  }
	for (int i = 0; i < n; i++)
	  {
		bob[i] = sc.nextInt ();

	  }
	for (int i = 0; i < alice.length; i++)
	  {
		if (alice[i] < 2 * bob[i] && bob[i] < 2 * alice[i])
		  {
			count++;
		  }
	  }
	System.out.println (count);

  }

}
