import java.util.*;
import java.lang.*;
import java.io.*;

class Add3_number
{
	public static void main (String[] args) throws java.lang.Exception
	{
        Scanner sc=new Scanner(System.in);
	   
	       int n=sc.nextInt();
	       int count=0;
	       int res1=(n*10)+3;
           n=res1;
            while(res1>0){
                int rem=res1%10;
                res1=res1/10;
                count++;
                }
            System.out.println(3*Math.pow(10,count)+n);
	 }
	}
// 	Approach2{
// 	    by removing inbuilt function:
// 	    int power=1
// 	    while(count>0){
// 	        power=power*10;
// 	        count--;
// 	    }
// 	    System.out.println((3*power*)+n);
// 	}