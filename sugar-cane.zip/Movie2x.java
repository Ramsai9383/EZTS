import java.util.*;
import java.lang.*;
import java.io.*;

class Movie2x
{
	public static void main (String[] args) throws java.lang.Exception
	{
        Scanner sc=new Scanner(System.in);
	   
	        int x=sc.nextInt();
	        int y=sc.nextInt();
	        System.out.println(minutes(x,y));
	       
	
	}
	 public static int minutes(int x,int y){
             int twox=(int)y/2;
	        return x-twox;
	 }
	    
	}