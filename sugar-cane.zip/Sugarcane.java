import java.util.*;
import java.util.Scanner;

public class Sugarcane
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int t=sc.nextInt();
	    while(t-->0){
	       int n=sc.nextInt();
            System.out.println(profits(n));

	   }
	}
	   public static int profits(int n){
	       int totalcoins=n*50;
	       int totalexpenditure=(int)(0.7*totalcoins);
	       return totalcoins-totalexpenditure;
	   }
        
	}

