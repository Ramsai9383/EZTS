import java.util.*;
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    
	    int n=sc.nextInt(); 
	    int x=sc.nextInt();
	    if((n-x)%4 ==0){
	           System.out.println((n-x)/4);
	       }
	       else{
	       System.out.println((n-x)/4 + 1);   
	   	}   
}}


