import java.util.*;
import java.lang.*;
import java.io.*;

class Occurences4
{
	public static void main (String[] args) throws java.lang.Exception
	{
        Scanner sc=new Scanner(System.in);
	   
	        int t=sc.nextInt();
	        while(t-->0){
	            int n=sc.nextInt();
	            System.out.println(check(n,0));
	            
	        }
	}
	        public static int check(int n,int count){
	            if(n==0){
	                return count;

	            }
	            int rem=n%10;
	            if(rem==4){
	                 count++;
	            }
	             return check(n/10,count);

	        }
	        
	}
	
	        
	        
	        
	        
	        
	        