
import java.util.*;
import java.util.Scanner;
public class Duplicate_ele
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int a[]=new int[7];
		for(int k=0;k<a.length;k++){
		    a[k]=sc.nextInt();
		}
		for(int i=0;i<a.length;i++){
		    for(int j=i+1;j<a.length;j++){
		        if(a[i]==a[j]){
		            System.out.println(a[i]);
		            return;
		        }
		        
		    }
		}

	}
}
