import java.util.*;
import java.util.Scanner;
class Main{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int flag=1;
         if(n<0){
             n=-1*n;
             flag=-1;
             
        }
        int res=0;

        while(n>0){
             res=res*10+n%10;
            n=n/10;
        }
        System.out.println(res*flag);
    }
}
