import java.util.*;
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int t=sc.nextInt();
	    while(t-->0){
	    int a=sc.nextInt();// 1st tv price
	    int b=sc.nextInt();// 2nd price
	    int c=sc.nextInt();// 1 discount
	    int d=sc.nextInt();// 2 discount
    
	        if((a-c)< (b-d)){
	            System.out.println("First");
	        }
	        else if((a-c)> (b-d)){
	            System.out.println("Second");
	        }
	        else{
	           System.out.println("Any");

	        }
	    }
	}   
}


